#!/bin/bash

tar cf rh7_oscap_files.tar ./*oscap*rh7.sh ./*oscap*rh7.py
rm -f ./*.sh
rm -f ./*.py
